from django.contrib import admin
from carts.models import Cart

admin.site.register(Cart)

# Register your models here.
